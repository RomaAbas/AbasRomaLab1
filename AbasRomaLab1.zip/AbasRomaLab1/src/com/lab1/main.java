package com.lab1;
import com.lab1.cctv;

public class main {

	public static void main(String[] args) {
		
		cctv c1 = new cctv ("Reolink", 1080, (float) 2.5, 4);
		System.out.println("Properties of CCTV C1: \n");
		System.out.println("Brand: " + c1.getBrand());
		System.out.println("Resolution: " + c1.getResolution() + "P");
		System.out.println("Lens Size: " + c1.getLensSize() + " inches");
		System.out.println("Optical Zoom: " + c1.getOpticalZoom() + "X");

	}

}
